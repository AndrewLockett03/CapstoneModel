import torch
print(torch.version.cuda)   # e.g. "12.4"
print(torch.cuda.is_available())